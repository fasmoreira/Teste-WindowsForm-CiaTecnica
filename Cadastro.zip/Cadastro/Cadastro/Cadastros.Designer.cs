﻿namespace Cadastro
{
    partial class Cadastro
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.mskCep = new System.Windows.Forms.MaskedTextBox();
            this.txtUF = new System.Windows.Forms.TextBox();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.lblUF = new System.Windows.Forms.Label();
            this.lblCidade = new System.Windows.Forms.Label();
            this.lblBairro = new System.Windows.Forms.Label();
            this.lblNumero = new System.Windows.Forms.Label();
            this.lblLogradouro = new System.Windows.Forms.Label();
            this.lblCEP = new System.Windows.Forms.Label();
            this.lblSobrenome = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.lblCPFObg = new System.Windows.Forms.Label();
            this.mskDateNascimento = new System.Windows.Forms.MaskedTextBox();
            this.maskCPF = new System.Windows.Forms.MaskedTextBox();
            this.btnValidarfisico = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtcomplemento = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtlogradouro = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtsobrenome = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnEnviarJuri = new System.Windows.Forms.Button();
            this.lblUFjuri = new System.Windows.Forms.Label();
            this.lblCidadejuri = new System.Windows.Forms.Label();
            this.lblbairrojuri = new System.Windows.Forms.Label();
            this.lblNumeroJuri = new System.Windows.Forms.Label();
            this.lblLogradourojuri = new System.Windows.Forms.Label();
            this.lblCEPJuri = new System.Windows.Forms.Label();
            this.lblnomefantasiaJurical = new System.Windows.Forms.Label();
            this.lblrazaoJuri = new System.Windows.Forms.Label();
            this.lblcnpjJuri = new System.Windows.Forms.Label();
            this.txtufjuri = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtcidadejuri = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtbairrojuri = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtcompljuri = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtnumjuridi = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtlogradourojuri = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtNomeFantasia = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtRazaoSocial = new System.Windows.Forms.TextBox();
            this.mskCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.mskCEPJuri = new System.Windows.Forms.MaskedTextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(639, 386);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.mskCep);
            this.tabPage1.Controls.Add(this.txtUF);
            this.tabPage1.Controls.Add(this.txtCidade);
            this.tabPage1.Controls.Add(this.txtBairro);
            this.tabPage1.Controls.Add(this.lblUF);
            this.tabPage1.Controls.Add(this.lblCidade);
            this.tabPage1.Controls.Add(this.lblBairro);
            this.tabPage1.Controls.Add(this.lblNumero);
            this.tabPage1.Controls.Add(this.lblLogradouro);
            this.tabPage1.Controls.Add(this.lblCEP);
            this.tabPage1.Controls.Add(this.lblSobrenome);
            this.tabPage1.Controls.Add(this.lblName);
            this.tabPage1.Controls.Add(this.lblDataNascimento);
            this.tabPage1.Controls.Add(this.lblCPFObg);
            this.tabPage1.Controls.Add(this.mskDateNascimento);
            this.tabPage1.Controls.Add(this.maskCPF);
            this.tabPage1.Controls.Add(this.btnValidarfisico);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.txtcomplemento);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtnumero);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtlogradouro);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtsobrenome);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtname);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(631, 360);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cadastro Pessoa Física";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // mskCep
            // 
            this.mskCep.Location = new System.Drawing.Point(441, 87);
            this.mskCep.Mask = "00000-000";
            this.mskCep.Name = "mskCep";
            this.mskCep.Size = new System.Drawing.Size(186, 20);
            this.mskCep.TabIndex = 46;
            this.mskCep.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskCep_MaskInputRejected);
            // 
            // txtUF
            // 
            this.txtUF.Location = new System.Drawing.Point(439, 240);
            this.txtUF.Name = "txtUF";
            this.txtUF.Size = new System.Drawing.Size(186, 20);
            this.txtUF.TabIndex = 45;
            this.txtUF.TextChanged += new System.EventHandler(this.txtUF_TextChanged);
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(219, 240);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(186, 20);
            this.txtCidade.TabIndex = 44;
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(6, 240);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(186, 20);
            this.txtBairro.TabIndex = 43;
            // 
            // lblUF
            // 
            this.lblUF.AutoSize = true;
            this.lblUF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUF.ForeColor = System.Drawing.Color.Red;
            this.lblUF.Location = new System.Drawing.Point(442, 263);
            this.lblUF.Name = "lblUF";
            this.lblUF.Size = new System.Drawing.Size(0, 16);
            this.lblUF.TabIndex = 42;
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCidade.ForeColor = System.Drawing.Color.Red;
            this.lblCidade.Location = new System.Drawing.Point(222, 262);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(0, 16);
            this.lblCidade.TabIndex = 41;
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBairro.ForeColor = System.Drawing.Color.Red;
            this.lblBairro.Location = new System.Drawing.Point(10, 264);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(0, 16);
            this.lblBairro.TabIndex = 40;
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero.ForeColor = System.Drawing.Color.Red;
            this.lblNumero.Location = new System.Drawing.Point(221, 183);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(0, 16);
            this.lblNumero.TabIndex = 39;
            // 
            // lblLogradouro
            // 
            this.lblLogradouro.AutoSize = true;
            this.lblLogradouro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogradouro.ForeColor = System.Drawing.Color.Red;
            this.lblLogradouro.Location = new System.Drawing.Point(6, 183);
            this.lblLogradouro.Name = "lblLogradouro";
            this.lblLogradouro.Size = new System.Drawing.Size(0, 16);
            this.lblLogradouro.TabIndex = 38;
            // 
            // lblCEP
            // 
            this.lblCEP.AutoSize = true;
            this.lblCEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCEP.ForeColor = System.Drawing.Color.Red;
            this.lblCEP.Location = new System.Drawing.Point(436, 110);
            this.lblCEP.Name = "lblCEP";
            this.lblCEP.Size = new System.Drawing.Size(0, 16);
            this.lblCEP.TabIndex = 37;
            // 
            // lblSobrenome
            // 
            this.lblSobrenome.AutoSize = true;
            this.lblSobrenome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobrenome.ForeColor = System.Drawing.Color.Red;
            this.lblSobrenome.Location = new System.Drawing.Point(216, 110);
            this.lblSobrenome.Name = "lblSobrenome";
            this.lblSobrenome.Size = new System.Drawing.Size(0, 16);
            this.lblSobrenome.TabIndex = 36;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Red;
            this.lblName.Location = new System.Drawing.Point(6, 110);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 16);
            this.lblName.TabIndex = 35;
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataNascimento.ForeColor = System.Drawing.Color.Red;
            this.lblDataNascimento.Location = new System.Drawing.Point(221, 48);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.Size = new System.Drawing.Size(0, 16);
            this.lblDataNascimento.TabIndex = 34;
            // 
            // lblCPFObg
            // 
            this.lblCPFObg.AutoSize = true;
            this.lblCPFObg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblCPFObg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPFObg.ForeColor = System.Drawing.Color.Red;
            this.lblCPFObg.Location = new System.Drawing.Point(7, 48);
            this.lblCPFObg.Name = "lblCPFObg";
            this.lblCPFObg.Size = new System.Drawing.Size(0, 16);
            this.lblCPFObg.TabIndex = 33;
            // 
            // mskDateNascimento
            // 
            this.mskDateNascimento.Location = new System.Drawing.Point(219, 21);
            this.mskDateNascimento.Mask = "00/00/0000";
            this.mskDateNascimento.Name = "mskDateNascimento";
            this.mskDateNascimento.Size = new System.Drawing.Size(186, 20);
            this.mskDateNascimento.TabIndex = 32;
            this.mskDateNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // maskCPF
            // 
            this.maskCPF.Location = new System.Drawing.Point(6, 21);
            this.maskCPF.Mask = "000.000.000-00";
            this.maskCPF.Name = "maskCPF";
            this.maskCPF.Size = new System.Drawing.Size(186, 20);
            this.maskCPF.TabIndex = 31;
            // 
            // btnValidarfisico
            // 
            this.btnValidarfisico.Location = new System.Drawing.Point(492, 320);
            this.btnValidarfisico.Name = "btnValidarfisico";
            this.btnValidarfisico.Size = new System.Drawing.Size(119, 34);
            this.btnValidarfisico.TabIndex = 26;
            this.btnValidarfisico.Text = "Cadastrar";
            this.btnValidarfisico.UseVisualStyleBackColor = true;
            this.btnValidarfisico.Click += new System.EventHandler(this.btnValidarfisico_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(442, 224);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "UF";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(222, 224);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Cidade";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 224);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Bairro";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // txtcomplemento
            // 
            this.txtcomplemento.Location = new System.Drawing.Point(439, 160);
            this.txtcomplemento.Name = "txtcomplemento";
            this.txtcomplemento.Size = new System.Drawing.Size(186, 20);
            this.txtcomplemento.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(442, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Complemento";
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(219, 160);
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(186, 20);
            this.txtnumero.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(222, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Numero";
            // 
            // txtlogradouro
            // 
            this.txtlogradouro.Location = new System.Drawing.Point(6, 160);
            this.txtlogradouro.Name = "txtlogradouro";
            this.txtlogradouro.Size = new System.Drawing.Size(186, 20);
            this.txtlogradouro.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Logradouro";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(442, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "CEP";
            // 
            // txtsobrenome
            // 
            this.txtsobrenome.Location = new System.Drawing.Point(219, 87);
            this.txtsobrenome.Name = "txtsobrenome";
            this.txtsobrenome.Size = new System.Drawing.Size(186, 20);
            this.txtsobrenome.TabIndex = 11;
            this.txtsobrenome.TextChanged += new System.EventHandler(this.txtsobrenome_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(222, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Sobrenome";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(6, 87);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(186, 20);
            this.txtname.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(222, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Data de Nascimento";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "CPF";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.mskCEPJuri);
            this.tabPage2.Controls.Add(this.btnEnviarJuri);
            this.tabPage2.Controls.Add(this.lblUFjuri);
            this.tabPage2.Controls.Add(this.lblCidadejuri);
            this.tabPage2.Controls.Add(this.lblbairrojuri);
            this.tabPage2.Controls.Add(this.lblNumeroJuri);
            this.tabPage2.Controls.Add(this.lblLogradourojuri);
            this.tabPage2.Controls.Add(this.lblCEPJuri);
            this.tabPage2.Controls.Add(this.lblnomefantasiaJurical);
            this.tabPage2.Controls.Add(this.lblrazaoJuri);
            this.tabPage2.Controls.Add(this.lblcnpjJuri);
            this.tabPage2.Controls.Add(this.txtufjuri);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.txtcidadejuri);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.txtbairrojuri);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.txtcompljuri);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.txtnumjuridi);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.txtlogradourojuri);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.txtNomeFantasia);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.txtRazaoSocial);
            this.tabPage2.Controls.Add(this.mskCNPJ);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(631, 360);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cadastro Pessoa Jurídica";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnEnviarJuri
            // 
            this.btnEnviarJuri.Location = new System.Drawing.Point(492, 313);
            this.btnEnviarJuri.Name = "btnEnviarJuri";
            this.btnEnviarJuri.Size = new System.Drawing.Size(123, 41);
            this.btnEnviarJuri.TabIndex = 30;
            this.btnEnviarJuri.Text = "Cadastrar";
            this.btnEnviarJuri.UseVisualStyleBackColor = true;
            this.btnEnviarJuri.Click += new System.EventHandler(this.btnEnviarJuri_Click);
            // 
            // lblUFjuri
            // 
            this.lblUFjuri.AutoSize = true;
            this.lblUFjuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUFjuri.ForeColor = System.Drawing.Color.Red;
            this.lblUFjuri.Location = new System.Drawing.Point(209, 235);
            this.lblUFjuri.Name = "lblUFjuri";
            this.lblUFjuri.Size = new System.Drawing.Size(0, 16);
            this.lblUFjuri.TabIndex = 29;
            // 
            // lblCidadejuri
            // 
            this.lblCidadejuri.AutoSize = true;
            this.lblCidadejuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCidadejuri.ForeColor = System.Drawing.Color.Red;
            this.lblCidadejuri.Location = new System.Drawing.Point(8, 235);
            this.lblCidadejuri.Name = "lblCidadejuri";
            this.lblCidadejuri.Size = new System.Drawing.Size(0, 16);
            this.lblCidadejuri.TabIndex = 28;
            // 
            // lblbairrojuri
            // 
            this.lblbairrojuri.AutoSize = true;
            this.lblbairrojuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbairrojuri.ForeColor = System.Drawing.Color.Red;
            this.lblbairrojuri.Location = new System.Drawing.Point(421, 168);
            this.lblbairrojuri.Name = "lblbairrojuri";
            this.lblbairrojuri.Size = new System.Drawing.Size(0, 16);
            this.lblbairrojuri.TabIndex = 27;
            // 
            // lblNumeroJuri
            // 
            this.lblNumeroJuri.AutoSize = true;
            this.lblNumeroJuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroJuri.ForeColor = System.Drawing.Color.Red;
            this.lblNumeroJuri.Location = new System.Drawing.Point(8, 168);
            this.lblNumeroJuri.Name = "lblNumeroJuri";
            this.lblNumeroJuri.Size = new System.Drawing.Size(0, 16);
            this.lblNumeroJuri.TabIndex = 25;
            // 
            // lblLogradourojuri
            // 
            this.lblLogradourojuri.AutoSize = true;
            this.lblLogradourojuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogradourojuri.ForeColor = System.Drawing.Color.Red;
            this.lblLogradourojuri.Location = new System.Drawing.Point(421, 106);
            this.lblLogradourojuri.Name = "lblLogradourojuri";
            this.lblLogradourojuri.Size = new System.Drawing.Size(0, 16);
            this.lblLogradourojuri.TabIndex = 24;
            // 
            // lblCEPJuri
            // 
            this.lblCEPJuri.AutoSize = true;
            this.lblCEPJuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCEPJuri.ForeColor = System.Drawing.Color.Red;
            this.lblCEPJuri.Location = new System.Drawing.Point(209, 106);
            this.lblCEPJuri.Name = "lblCEPJuri";
            this.lblCEPJuri.Size = new System.Drawing.Size(0, 16);
            this.lblCEPJuri.TabIndex = 23;
            // 
            // lblnomefantasiaJurical
            // 
            this.lblnomefantasiaJurical.AutoSize = true;
            this.lblnomefantasiaJurical.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnomefantasiaJurical.ForeColor = System.Drawing.Color.Red;
            this.lblnomefantasiaJurical.Location = new System.Drawing.Point(8, 106);
            this.lblnomefantasiaJurical.Name = "lblnomefantasiaJurical";
            this.lblnomefantasiaJurical.Size = new System.Drawing.Size(0, 16);
            this.lblnomefantasiaJurical.TabIndex = 22;
            // 
            // lblrazaoJuri
            // 
            this.lblrazaoJuri.AutoSize = true;
            this.lblrazaoJuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrazaoJuri.ForeColor = System.Drawing.Color.Red;
            this.lblrazaoJuri.Location = new System.Drawing.Point(209, 46);
            this.lblrazaoJuri.Name = "lblrazaoJuri";
            this.lblrazaoJuri.Size = new System.Drawing.Size(0, 16);
            this.lblrazaoJuri.TabIndex = 21;
            // 
            // lblcnpjJuri
            // 
            this.lblcnpjJuri.AutoSize = true;
            this.lblcnpjJuri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnpjJuri.ForeColor = System.Drawing.Color.Red;
            this.lblcnpjJuri.Location = new System.Drawing.Point(8, 46);
            this.lblcnpjJuri.Name = "lblcnpjJuri";
            this.lblcnpjJuri.Size = new System.Drawing.Size(0, 16);
            this.lblcnpjJuri.TabIndex = 20;
            // 
            // txtufjuri
            // 
            this.txtufjuri.Location = new System.Drawing.Point(212, 212);
            this.txtufjuri.Name = "txtufjuri";
            this.txtufjuri.Size = new System.Drawing.Size(172, 20);
            this.txtufjuri.TabIndex = 19;
            this.txtufjuri.TextChanged += new System.EventHandler(this.txtufjuri_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(209, 196);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 13);
            this.label20.TabIndex = 18;
            this.label20.Text = "UF";
            // 
            // txtcidadejuri
            // 
            this.txtcidadejuri.Location = new System.Drawing.Point(8, 212);
            this.txtcidadejuri.Name = "txtcidadejuri";
            this.txtcidadejuri.Size = new System.Drawing.Size(172, 20);
            this.txtcidadejuri.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(5, 196);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 13);
            this.label21.TabIndex = 16;
            this.label21.Text = "Cidade";
            // 
            // txtbairrojuri
            // 
            this.txtbairrojuri.Location = new System.Drawing.Point(424, 145);
            this.txtbairrojuri.Name = "txtbairrojuri";
            this.txtbairrojuri.Size = new System.Drawing.Size(172, 20);
            this.txtbairrojuri.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(421, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Bairro";
            // 
            // txtcompljuri
            // 
            this.txtcompljuri.Location = new System.Drawing.Point(212, 145);
            this.txtcompljuri.Name = "txtcompljuri";
            this.txtcompljuri.Size = new System.Drawing.Size(172, 20);
            this.txtcompljuri.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(209, 129);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 13);
            this.label18.TabIndex = 12;
            this.label18.Text = "Complemento";
            // 
            // txtnumjuridi
            // 
            this.txtnumjuridi.Location = new System.Drawing.Point(8, 145);
            this.txtnumjuridi.Name = "txtnumjuridi";
            this.txtnumjuridi.Size = new System.Drawing.Size(172, 20);
            this.txtnumjuridi.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 10;
            this.label19.Text = "Numero";
            // 
            // txtlogradourojuri
            // 
            this.txtlogradourojuri.Location = new System.Drawing.Point(424, 83);
            this.txtlogradourojuri.Name = "txtlogradourojuri";
            this.txtlogradourojuri.Size = new System.Drawing.Size(172, 20);
            this.txtlogradourojuri.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(421, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Logradouro";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(209, 67);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 6;
            this.label15.Text = "CEP";
            // 
            // txtNomeFantasia
            // 
            this.txtNomeFantasia.Location = new System.Drawing.Point(8, 83);
            this.txtNomeFantasia.Name = "txtNomeFantasia";
            this.txtNomeFantasia.Size = new System.Drawing.Size(172, 20);
            this.txtNomeFantasia.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "Nome Fantasia";
            // 
            // txtRazaoSocial
            // 
            this.txtRazaoSocial.Location = new System.Drawing.Point(212, 23);
            this.txtRazaoSocial.Name = "txtRazaoSocial";
            this.txtRazaoSocial.Size = new System.Drawing.Size(172, 20);
            this.txtRazaoSocial.TabIndex = 3;
            // 
            // mskCNPJ
            // 
            this.mskCNPJ.Location = new System.Drawing.Point(8, 23);
            this.mskCNPJ.Mask = "00.000.000/0000-00";
            this.mskCNPJ.Name = "mskCNPJ";
            this.mskCNPJ.Size = new System.Drawing.Size(172, 20);
            this.mskCNPJ.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(209, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Razão Social";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "CNPJ";
            // 
            // mskCEPJuri
            // 
            this.mskCEPJuri.Location = new System.Drawing.Point(212, 83);
            this.mskCEPJuri.Mask = "00000-000";
            this.mskCEPJuri.Name = "mskCEPJuri";
            this.mskCEPJuri.Size = new System.Drawing.Size(172, 20);
            this.mskCEPJuri.TabIndex = 31;
            this.mskCEPJuri.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskCEPJuri_MaskInputRejected);
            // 
            // Cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 408);
            this.Controls.Add(this.tabControl1);
            this.Name = "Cadastro";
            this.Text = "Teste Felippe Augusto";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtcomplemento;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtlogradouro;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtsobrenome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnValidarfisico;
        private System.Windows.Forms.MaskedTextBox maskCPF;
        private System.Windows.Forms.MaskedTextBox mskDateNascimento;
        private System.Windows.Forms.Label lblUF;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label lblLogradouro;
        private System.Windows.Forms.Label lblCEP;
        private System.Windows.Forms.Label lblSobrenome;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.Label lblCPFObg;
        private System.Windows.Forms.TextBox txtUF;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.MaskedTextBox mskCep;
        private System.Windows.Forms.Button btnEnviarJuri;
        private System.Windows.Forms.Label lblUFjuri;
        private System.Windows.Forms.Label lblCidadejuri;
        private System.Windows.Forms.Label lblbairrojuri;
        private System.Windows.Forms.Label lblNumeroJuri;
        private System.Windows.Forms.Label lblLogradourojuri;
        private System.Windows.Forms.Label lblCEPJuri;
        private System.Windows.Forms.Label lblnomefantasiaJurical;
        private System.Windows.Forms.Label lblrazaoJuri;
        private System.Windows.Forms.Label lblcnpjJuri;
        private System.Windows.Forms.TextBox txtufjuri;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtcidadejuri;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtbairrojuri;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtcompljuri;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtnumjuridi;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtlogradourojuri;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtNomeFantasia;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtRazaoSocial;
        private System.Windows.Forms.MaskedTextBox mskCNPJ;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox mskCEPJuri;
    }
}

